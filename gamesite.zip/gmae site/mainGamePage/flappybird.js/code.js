function Game(){
    Start.style.visibility="hidden";
    var flysound=document.getElementById("fly"); 
    var diesound=document.getElementById("die");
    var pointsound=document.getElementById("point"); 
    document.body.style.maxWidth=innerWidth;
    document.body.style.maxHeight=innerHeight;
    onetime=true;
    var score;
    var help=0;
    var scoreNumber=0;
    var bird=document.createElement("div");
    var isOnAir=true;
    var wallleft=innerWidth-parseInt(innerWidth/40);
    var downtop;
    var count=0;
    var wall=[];
    var plustop=1;
    var plusleft=0.5;
    var t=0;
    var r,c;
    r=0;c=0;
    document.body.appendChild(bird);
    function reload(){
        location.reload();
    }
    function randomTopPosition(){
        var x=parseInt(Math.random()*innerWidth);
        while(x>innerHeight-birdheight*4 || x < birdheight*2){
            x=parseInt(Math.random()*innerWidth);
        }
        return x;
    }
    function die(){
        for(var i=0;i<3;i++){
            wall[i].object.style.visibility="hidden";
            wall[i].object2.style.visibility="hidden";
            Start.style.visibility="visible";
            
            
        }
        Start.onmousedown=reload;
        Start.innerHTML="Play Agien";
        score.style.top=innerHeight/15;
        Start.style.top=innerHeight/5;
        score.innerHTML="Score: "+score.innerHTML;
        score.style.fontSize=innerHeight/20;
        isOnAir=false;
        clearInterval(timer); 
        diesound.play();
        
        bird.style.backgroundImage="url('birddie.png')";
    }
    var birdtop,birdleft,birdwidth,birdheight;
    function birdActivate(){
        birdtop=parseInt(innerHeight/2);
        birdleft=parseInt(innerWidth/6);
        birdwidth=parseInt(innerWidth/20);
        birdheight=parseInt(innerHeight/12);
        bird.style.position="absolute";
        bird.style.top=birdtop;
        bird.style.left=birdleft;
        bird.style.width=birdwidth;
        bird.style.height=birdheight;
        bird.style.backgroundImage="url('bird.png')";
        bird.style.backgroundSize="100%";
        bird.style.backgroundRepeat="no-repeat"; 
    }
    birdActivate();
    function birdGetDown(){
        var down=0;
        while(down<50 && isOnAir){
            birdtop+=1;
            bird.style.top=birdtop;
            if(birdtop+birdheight==innerHeight){
                isOnAir=false;
                clearInterval(timer);  
            } 
            down+=1;
            for(var r=0;r<3;r++){
                wall[r].wallleft-=0.5;
                wall[r].object.style.left=wall[r].wallleft;
                wall[r].object2.style.left=wall[r].wallleft;
                if(wall[r].wallleft+wall[r].wallwidth<=0){
                    wall[r].wallleft=innerWidth-wall[r].wallwidth;
                    wall[r].reposition(); 
                }
                if(birdleft>=wall[r].wallleft && birdleft<wall[r].wallleft+wall[r].wallwidth){
                    if(birdtop>=wall[r].upheight && birdtop+birdheight<wall[r].downtop){
                        if(help!=r){
                            help=r;
                            scoreNumber++;
                            pointsound.play();
                            score.innerHTML=String(scoreNumber);
                        }   
                    }  
                }
                 else{
                        if(birdleft+birdwidth == wall[r].wallleft && (birdtop<wall[r].upheight || birdtop+birdheight >= wall[r].downtop)){
                            die();
                        }
                    }
                if(birdleft >= wall[r].wallleft && birdleft<=wall[r].wallleft+wall[r].wallwidth){
                    if(birdtop<wall[r].upheight ){
                        die();
                        bird.style.top=wall[r].upheight;
                    }
                    else if( birdtop+birdheight>wall[r].downtop){
                        die();
                        bird.style.top=wall[r].downtop;
                    }
                }
                if(birdleft<wall[r].wallleft && birdleft+birdwidth>wall[r].wallleft){
                    if(birdtop+birdheight>wall[r].downtop){
                        die();
                    }
                    else if(birdtop<wall[r].upheight){

                    }   
                } 
            }
        }
        function birdMove(presskey){
                if(isOnAir){
                    if(presskey.keyCode ==32 ){
                        flysound.play();
                        for(var up =0;up<150;up++){
                            if(birdtop != 0){
                                birdtop-=plustop;
                                bird.style.top=birdtop;
                            }
                        }
                    }
                }
            }
        document.onkeydown=birdMove;
    }
    var timer= setInterval(birdGetDown,100);
    function Walls(){      
        this.wallwidth=parseInt(innerWidth/15);
        this.wallleft=wallleft;
        this.upheight=randomTopPosition();
        this.downtop=this.upheight+parseInt(birdheight*3.5);
        this.downheight=innerHeight-this.downtop;
        this.object=document.createElement("div");
        this.object.style.position="absolute";
        this.object.style.left=this.wallleft;
        this.object.style.top=0;
        this.object.style.width=this.wallwidth;
        this.object.style.height=this.upheight;
        this.object.style.backgroundImage="url('wallup.png')";
        this.object.style.transform="rotate(180deg)";
        this.object.style.backgroundSize="100%";
        this.object.style.backgroundRepeat="no-repeat";
        document.body.appendChild(this.object);
        this.object2=document.createElement("div");
        this.object2.style.position="absolute";
        this.object2.style.left=this.wallleft;
        this.object2.style.top=this.downtop;
        this.object2.style.width=this.wallwidth;
        this.object2.style.height=this.downheight;
        this.object2.style.backgroundImage="url('wallup.png')";
        this.object2.style.backgroundSize="100%";
        this.object2.style.backgroundRepeat="no-repeat";
        document.body.appendChild(this.object2);
        this.reposition=function(){
                this.upheight=randomTopPosition();
                this.downtop=this.upheight+parseInt(birdheight*3.5);
                this.downheight=innerHeight-this.downtop;
                this.object.style.height=this.upheight;
                this.object2.style.top=this.downtop;
                this.object2.style.height=this.downheight;
            } 
    }
    for(var i=0;i<3;i++){
        wall[i]=new Walls();
        wallleft-=parseInt(innerWidth/3);
    }
    function Score(){
        score=document.createElement("div");
        document.body.appendChild(score);
        score.style.position="absolute";
        score.style.top=parseInt(innerHeight*20/100);
        score.style.left=parseInt(innerWidth*40/100);
        score.style.width=parseInt(innerWidth*10/100);
        score.style.height=parseInt(innerHeight*20/100);
        score.innerHTML=String(scoreNumber);
        score.style.fontSize=innerHeight*20/100;
        score.style.textAlign="center";
        score.style.color="grey";
        score.style.fontFamily="system-ui";    
    }
    Score();
}
var Start=document.createElement("div");
document.body.appendChild(Start);
Start.style.position="absolute";
Start.style.top=parseInt(innerHeight*30/100);
Start.style.left=parseInt(innerWidth*40/100);
Start.style.width=parseInt(innerWidth*20/100);
Start.style.height=parseInt(innerHeight*10/100);
Start.style.backgroundColor="#167a6e";
Start.style.border=" 15px double #545d66";
Start.style.textAlign="center";
Start.innerHTML="Start Play";
Start.style.fontFamily="Impact";
Start.style.fontSize=parseInt(innerHeight/15);
Start.onmousedown=Game;
