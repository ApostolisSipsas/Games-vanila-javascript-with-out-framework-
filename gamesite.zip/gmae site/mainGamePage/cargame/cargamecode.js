var world =document.getElementById("world");

world.style.backgroundColor="red";
world.style.position="absolute";
world.style.top=100;
world.style.left=100;
world.style.width=innerWidth/2-200;
world.style.height=innerHeight-200;