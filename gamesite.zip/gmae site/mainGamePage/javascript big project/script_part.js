function Block(){
	this.CreateBlock=function(){
		this.block_child=document.createElement("div");
		this.block_child.setAttribute("id","Block_code");
		document.body.appendChild(this.block_child);
        this.block=document.getElementById("Block_code");
        this.score=0;
	};
	this.Activate=function(){
        this.random=parseInt(Math.random()*innerWidth);
		this.block_height=parseInt(innerHeight*8/100);
		this.block.style.height=this.block_height;
        this.block_width=parseInt(innerWidth*10/100);
		this.block.style.width=this.block_width;
		this.block.style.visibility="visible";
		this.block.style.backgroundImage='url("scorebord.gif")';
        this.block.style.position="absolute";
        this.block_positiony=15;
        this.block.style.top=this.block_positiony;
        while (this.random > innerWidth-(this.block_width+15)){
            this.random=parseInt(Math.random()*innerWidth);
        }
		this.block.style.left=this.random;
		this.block.style.borderStyle="solid";
        this.block.style.borderColor="#60396d";
        this.block.style.borderWidth="5px";
        this.block.style.fontWeight="bold";
        this.block.style.fontFamily='"Comic Sans MS", cursive, sans-serif';
        this.block.style.color="#990d0d";
        this.block.style.textAlign="center";
        this.block.innerHTML=" Your Score: "+String(this.score);
    };
    this.hide =function(){
        this.block.style.visibility="hidden";
    };
   
    this.check=function(){
        if(circle_positionx+parseInt(circle_width/2) >= this.random  && circle_positionx+parseInt(circle_width/2)<=this.random+this.block_width){
            if(this.block_positiony == circle_positiony+circle_height){
                y_change=-y_change;
                this.score+=1;
                this.Activate();
                dsound.play();
            }
            if(this.block_positiony +this.block_height == circle_positiony ){
                y_change=-y_change;
                this.score+=1;
                this.Activate();
                dsound.play();
            }
        }
        if(circle_positiony+parseInt(circle_height/2)>= this.block_positiony && circle_positiony+parseInt(circle_height/2) <= this.block_positiony+this.block_height){
            if(circle_positionx+circle_width == this.random){
                x_change=-x_change;
                this.score+=1;
                this.Activate();
                dsound.play();
            }
            if(circle_positionx == this.random+this.block_width){
                x_change=-x_change;
                
                this.score+=1;
                this.Activate();
                dsound.play();
            }
        }
        if(
            (circle_positiony+circle_height >this.block_positiony && circle_positiony+parseInt(circle_height/2)<this.block_positiony)
        &&
            (circle_positionx+circle_width> this.random && circle_positionx+parseInt(circle_width/2)<this.random)
        ){
            x_change=-x_change;
            this.score+=1;
            this.Activate();
            dsound.play();
        }
        else if(
            (circle_positionx<this.random+this.block_width && circle_positionx+parseInt(circle_width/2) > this.random+this.block_width)
        &&
            (circle_positiony+circle_height > this.block_positiony &&  circle_positiony+parseInt(circle_height/2) < this.block_positiony)
        ){
            x_change=-x_change;
            this.score+=1;
            this.Activate();
            dsound.play();
        }
        else if(
            (circle_positiony< this.block_positiony +this.block_height && circle_positiony+parseInt(circle_height/2)> this.block_positiony +this.block_height)
        &&
            (circle_positionx+circle_width > this.random && circle_positionx+parseInt(circle_width/2)< this.random)
        ){
            x_change=-x_change;
            y_change=-y_change;
            this.score+=1;
            this.Activate();
            dsound.play();
        }
        else if(
            (circle_positionx < this.random+this.block_width && circle_positionx+parseInt(circle_width/2)> this.random+this.block_width)
        &&
            (circle_positiony<this.block_positiony+this.block_height && circle_positiony+parseInt(circle_height/2) > this.block_positiony+this.block_height)
        ){
            x_change=-x_change;
            y_change=-y_change;
            this.score+=1;
            this.Activate();
            dsound.play();
        }
    };
};
var block= new Block();
var dsound=document.getElementById("sound1");
var bsound=document.getElementById("sound2");
var gameover_sound=document.getElementById("gameoversound");
var circle=document.getElementById("circle");
var rect=document.getElementById("rect");
var circle_positionx,circle_positiony,circle_width,circle_height ,rect_positionx,rect_positiony,rect_height,rect_width;
circle_positionx=parseInt(innerWidth*15/100);
circle_positiony=parseInt(innerHeight*11/100);

rect_positionx=parseInt(innerWidth*45/100);
rect_positiony=parseInt(innerHeight*82/100);

rect_width=parseInt(innerWidth*10/100);
rect.style.width=rect_width;
rect_height=parseInt(innerHeight*1.5/100);
rect.style.height=rect_height;

circle_height=parseInt(innerHeight*6/100);

circle_width=parseInt(innerWidth*3/100);



var i;
x_change=1;
y_change=1;
var plus_x=10;
var plus_y=10;
function reload_funtion(){
    location.reload();
}
function rect_single(x){
    for(i=1;i<=40;i++){
        if(rect_positionx+rect_width +15< innerWidth && rect_positionx >15){
            rect_positionx+=x;
            rect.style.left=rect_positionx;
        }
        else{
            i=41;
        }
    }
    }
function rect_duble(x){
    for( i=1;i<=80;i++){
        if(rect_positionx+rect_width +15<= innerWidth && rect_positionx >=15){
            rect_positionx+=x;
            rect.style.left=rect_positionx;
        }
        else{
            i=81;
        }
    }
    }
var key=0;
function rect_event (pressedKey){
    switch(pressedKey.keyCode){
        case 37:
            if(key== 39){
                rect_duble(-1);
                }
            else{
                rect_single(-1);
            }
        key=37;
        break;

    case 39:
    if(key== 37){
        rect_duble(+1);}
    else{
        rect_single(+1);
    }
    key=39;
    break;


    }}
    
function ball_event(){
    requestAnimationFrame(ball_event);

        for(var i=1;i<=plus_x;i++){
            if(circle_positionx +circle_width+10 == innerWidth || circle_positionx == 10 ){
                x_change=-x_change;
                bsound.play();
            }
            if(circle_positiony == 10){
                y_change=-y_change;
                bsound.play();
            }
            if(circle_positiony +circle_height == rect_positiony ){
                if(circle_positionx + circle_width/2>= rect_positionx -5 && circle_positionx+circle_width/2 <= rect_positionx+rect_width+5 ){
                    y_change=-y_change;
                    bsound.play();
                }
            }
            if(circle_positiony+circle_height >= rect_positiony+5 &&(
            circle_positionx+circle_width/2 >= rect_positionx-5 && circle_positionx <= rect_positionx-5
            ||
            circle_positionx+circle_width/2 >= rect_positionx+rect_width+5 && circle_positionx <= rect_positionx+rect_width+2
            )){
                x_change=-x_change;
                y_change=-y_change;
                bsound.play();
            }
            else if( circle_positiony+circle_height >= rect_positiony-5){
                if(circle_positionx +circle_width==rect_positionx -5 || circle_positionx == rect_positionx+rect_width+5 ){
                    x_change=-x_change;
                    y_change=-y_change;
                    bsound.play();
                }
            }
            block.check();
  

            

            circle_positionx+=x_change;
            circle_positiony+=y_change;
        }
        circle.style.top=circle_positiony;
        circle.style.left=circle_positionx;

        rect.style.left=rect_positionx;
        rect.style.top=rect_positiony;
        if(circle_positiony > rect_positiony){
            plus_x=0;
            plus_y=0;
            circle_positiony=0;
            rect_positiony=0;
            circle.style.visibility="hidden";
            rect.style.visibility="hidden";
            document.body.style.backgroundImage="url('lastbgimage.png')";
            document.getElementById("img").style.visibility="hidden";
            document.getElementById("img2").style.visibility="hidden";
            document.getElementById("gameover_image").style.visibility="visible";
            circle.style.fontWeight = "1100";
            circle.style.left=innerWidth/2;
            circle.style.top=innerHeight/3;
            var scoretext=document.createElement("p");
            scoretext.innerHTML="Nice Try!!! That Is Your Score : "+(block.score);
            scoretext.style.position="absolute";
            scoretext.style.left=innerWidth/2-innerWidth*30/100/2;
            scoretext.style.top=innerHeight/1.5;
            scoretext.style.textAlign="center";
            scoretext.style.width=innerWidth*30/100;
            scoretext.style.fontFamily='"Comic Sans MS", cursive, sans-serif';
            scoretext.style.fontWeight="bold";
            scoretext.style.color="#af342b";
            scoretext.style.fontSize="29";
            document.body.appendChild(scoretext);
            var button_generate=document.createElement("button");
            var button_value =document.createTextNode("Press to continue");
            button_generate.appendChild(button_value);
            button_generate.setAttribute("id","button_end");
            document.body.appendChild(button_generate);
            var buttonLast= document.getElementById("button_end");
            buttonLast.setAttribute("onClick","reload_funtion()");
            buttonLast.style.backgroundColor="lightblue";
            buttonLast.style.fontSize="25";
            buttonLast.style.fontWeight="bold";
            buttonLast.style.width=innerWidth*30/100;
            buttonLast.style.position="absolute";
            buttonLast.style.top=innerHeight/1.3;
            buttonLast.style.left=innerWidth/2-innerWidth*30/100/2;
            block.hide();
            gameover_sound.play();
            }
    document.onkeydown =rect_event;
    }



function run_doc(){
    document.getElementById("code_run").style.visibility = "hidden";
    document.getElementById("code_block").style.visibility = "hidden";
    circle.style.visibility ="visible";
    rect.style.visibility="visible";
    document.getElementById("img2").style.visibility = "visible";
    document.getElementById("img").style.visibility = "visible";
    block.CreateBlock();
    block.Activate();
    ball_event();
   
}

function win_close(){
	window.close();
}
