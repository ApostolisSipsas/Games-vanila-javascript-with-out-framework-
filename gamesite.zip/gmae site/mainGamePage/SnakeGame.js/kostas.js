var st1,sl1,s1w,s1h,st2,sl2,s2w,s2h;
st1=0;
sl1=0;
s1w=parseInt(innerWidth);
s1h=parseInt(innerHeight/2);
st2=parseInt(innerHeight-s1h);
sl2=0;
s2w=parseInt(innerWidth);
s2h=innerHeight-st2;
var slideUp=document.getElementById("sk");
slideUp.style.position="absolute";
slideUp.style.top=st1;
slideUp.style.backColor="grey";
slideUp.style.left=sl1;
slideUp.style.width=s1w;
slideUp.style.heigth=s1w;
var slideDown=document.getElementById("sk2");
slideDown.style.backColor="grey";
slideDown.style.top=st2;
slideDown.style.left=sl2;
slideDown.style.width=s2w;
slideDown.style.heigth=s2h;
function openSite(){
    if(s1h>0){
        s1h-=10;
    }
    if(st2<innerHeight){
        st2-=10;
        s2h-=10;
    }

}
var timer=setInterval(openSite,100);
