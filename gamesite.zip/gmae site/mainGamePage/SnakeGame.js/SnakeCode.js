function GameStart(){
    var count=false;
    var losetop,loseleft,loseheihgt,losewidth;
    var back=document.getElementById("close");
    back.style.top=0;
    back.style.left=innerWidth/2.5;
    
    var endtime,loseef;
    
    var startButton =document.getElementById("start");
    startButton.style.visibility="hidden";
    var foodsound=document.getElementById("eatsound");
    

    var World=document.getElementById("world");
    var worldtop=parseInt(innerHeight*10/100);
    var worldleft=parseInt(innerWidth*10/100);
    var worldheight=parseInt(innerHeight*80/100);
    var worldwidth=parseInt(innerWidth*80/100);
    losetop=parseInt(worldheight/2);
    loseleft=parseInt(worldwidth/2);
    loseheight=0;
    losewidth=0;
    World.style.left=worldleft;
    World.style.top=worldtop;
    World.style.height=worldheight;
    World.style.width=worldwidth;
    World.style.border="20px groove blue";
    var startSound=document.getElementById("startSound");
    startSound.play();
    var slideup=document.createElement("div");
    var slideupheight=parseInt(worldheight/2);
    var slideleft=document.createElement("div");
    var slideleftwidth=parseInt(worldwidth/2);
    var slidedown=document.createElement("div");
    var slidedowntop=slideupheight;
    var slidedownheight=worldheight-slidedowntop;
    var slideright=document.createElement("div");
    var sliderightleft=slideleftwidth;
    var sliderightwidth=worldwidth-sliderightleft;
    World.appendChild(slideup);
    World.appendChild(slideleft);
    World.appendChild(slidedown);
    World.appendChild(slideright);
        slideup.style.position="absolute";
        slideup.style.top=0;
        slideup.style.left=0;
        slideup.style.height=slideupheight;
        slideup.style.width=worldwidth;
        slideup.style.backgroundColor="#132639";
        slidedown.style.position="absolute";
        slidedown.style.top=slidedowntop;
        slidedown.style.left=0;
        slidedown.style.height=slidedownheight;
        slidedown.style.width=worldwidth;
        slidedown.style.backgroundColor="#132639";
        slideleft.style.position="absolute";
        slideleft.style.left=0;
        slideleft.style.top=0;
        slideleft.style.width=slideleftwidth;
        slideleft.style.height=worldheight;
        slideleft.style.backgroundColor="#132639";
        slideright.style.position="absolute";
        slideright.style.top=0;
        slideright.style.left=sliderightleft;
        slideright.style.width=sliderightwidth;
        slideright.style.height=worldheight;
        slideright.style.backgroundColor="#132639";
        var lose;
        function makeTheSlide(){
                SnakeBody[0].object.style.visibility="hidden";
                food.Food.style.visibility="hidden";
                    slideupheight-=1;
                    slideup.style.height=slideupheight;
                    slidedownheight-=1;
                    slidedowntop+=1;
                    slidedown.style.top=slidedowntop;
                    slidedown.style.height=slidedownheight;
                    slideleftwidth-=2;
                    slideleft.style.width=slideleftwidth;
                    sliderightwidth-=2;
                    sliderightleft+=2;
                    slideright.style.left=sliderightleft;
                    slideright.style.width=sliderightwidth;
                    if(slideupheight<0 && slidedownheight<0 &&slideleftwidth<0&&sliderightwidth<0){
                        slideright.style.visibility="hidden";
                        slideleft.style.visibility="hidden";
                        slidedown.style.visibility="hidden";
                        slideup.style.visibility="hidden";
                        startSound.pause();
                        clearInterval(time);
                        SnakeBody[0].object.style.visibility="visible";
                        food.Food.style.visibility="visible";
                    }
            }
    var time=setInterval(makeTheSlide,1);
    var SnakeBody=[];
    var gps=0;
    function SnakePart(){
        this.object=document.createElement("div");
        this.createPart = function(top,left){
            this.top=top;
            this.left=left;
            World.appendChild(this.object);
            this.object.style.backgroundSize="100%";
            this.object.style.position="absolute";
            this.object.style.backgroundRepeat="no-reapeat";
            this.object.style.top=top;
            this.object.style.left=left;
            this.object.style.width=20;
            this.object.style.height=20;
            this.object.style.borderRadius="5px"
            this.object.style.backgroundColor="blue";
        }
        this.setLocation = function(x,y){
            this.object.style.left=x;
            this.object.style.top=y;
            this.top=y;
            this.left=x;
        }
        this.getTop = function(){
            return this.top;
        }
        this.getLeft=function(){
            return this.left;
        }
    }
    function MakeFood(){
        var top=parseInt(Math.random()*worldheight);
        var left=parseInt(Math.random()*worldwidth);
        this.Food =document.createElement("div");
        World.appendChild(this.Food);
        this.Food.style.position="absolute";
        this.Food.style.width=30;
        this.Food.style.height=30;
        this.Food.style.top=top;
        this.Food.style.left=left;
        this.Food.style.backgroundSize="100%"
        this.Food.style.backgroundImage = "url('food.jpg')";
        this.getTop=function(){
            return top;
        }
        this.getLeft=function(){
            return left;
        }
        this.die=function(){
            top=parseInt(Math.random()*worldheight);
            left=parseInt(Math.random()*worldwidth);
            while(top < 30 || top >innerHeight-30){
                top=parseInt(Math.random()*worldheight);
            }
            while(left>innerWidth-30 || left<30){
                left=parseInt(Math.random()*worldwidth);
            }
            this.Food.style.top=top;
            this.Food.style.left=left;
        }
    }
    var food =new MakeFood();
    var plustop,plusleft,topPosition,leftPosition,partWidth,partHeight,foodTop,foodLeft,plusx,plusy;
    leftPosition=parseInt(innerWidth/2);
    topPosition=parseInt(innerHeight/2);
    plustop=0;
    plusleft=0;
    SnakeBody[0]= new SnakePart();
    SnakeBody[0].createPart(topPosition,leftPosition);
    leftPosition+=20;
    function keyBordActivate(Key){
        switch(Key.keyCode){
            case 40:
            if(plustop!=-20){
                plustop=20;
                y1=1;
                x1=0;
                plusleft=0;
            }
            break;
            case 38:
                if(plustop!=20){
                    plustop=-20;
                    y1=-1;
                    x1=0;
                    plusleft=0;
                }
                break;
            case 37:
                if(plusleft!=20) {
                    plusleft=-20;
                    x1=-1;
                    y1=0;
                    plustop=0;}
            break;
            case 39:
                if(plusleft!=-20 ){
                    plusleft=20;
                    x1=1;
                    y1=0;
                    plustop=0;
                }
                break;
        }
    }
    function Game(){
        document.onkeydown=keyBordActivate;
            if(plusleft!=0 || plustop!=0){
                for(var i=0;i<20;i++){
                    topPosition+=y1;
                    leftPosition+=x1;
                    for(var k=0;k<SnakeBody.length;k++){
                        if(gps != k){
                                if(leftPosition==SnakeBody[k].getLeft()){
                                    if(topPosition==SnakeBody[k].getTop()){
                                        for(var m=0;m < SnakeBody.length;m++){
                                            SnakeBody[m].object.style.visibility="hidden";
                                        }
                                        if(!stop){
                                       
                                            stop=true;
                                            plustop=0;
                                            plusleft=0;
                                            lose=document.createElement("div");
                                            food.Food.style.visibility="hidden";
                                            lose.style.transform="translate(50%,50%)";
                                            lose.style.backgroundSize="100%";
                                            lose.style.height=loseheight;
                                            lose.style.width=losewidth;
                                            lose.style.position="absolute";
                                            lose.style.top=losetop;
                                            lose.style.left=loseleft;
                  
                                            lose.style.backgroundImage="url('gameover.png')";
                                            World.appendChild(lose);
                                            function endslide(){
                                                
                                                if(losewidth<600){
                                                    
                                                    loseleft-=2;
                                                    losewidth+=2;
                                                }
                                                if(loseheight<600){
                                                    losetop-=2;
                                                    loseheight+=2;
                                                }
                                                

                                                lose.style.top=losetop;
                                                lose.style.left=loseleft;
                                                lose.style.width=losewidth;
                                                lose.style.height=loseheight;
                                                if(losewidth>600){
                                                    
                                                    clearInterval(endslider);
                                                    

                                                }
                                            }


                                        }
     
                                        endslider=setInterval(endslide,1);
                                        
                                        startButton.style.visibility="visible";
                                        startButton.style.top=0;
                                        startButton.style.left=innerWidth/4;
                                        startButton.value="Play Agien !!";
    
                                        back.style.transform="translate(100%,0%)";
                                        back.style.left=innerWidth/3;
                                        startButton.onmousedown=function(){
                                            location.reload();}
                                            
                                    }
                                }
                            }
                        }
                    switch(plusleft){
                        case 20:
                            if(leftPosition+20==worldwidth+20){
                                leftPosition=-20;
                            }
                            break;
                        case -20:
                            if(leftPosition ==-20){
                                leftPosition=worldwidth;
                            }
                            break;
                    }
                    switch(plustop){
                        case 20:
                            if(topPosition +20 == worldheight+20){
                                topPosition=-20;
                            }
                            break;
                        case -20:
                            if(topPosition==-20){
                                topPosition=worldheight;
                            }
                            break;
                    }
                    if(topPosition >= food.getTop()  &&  topPosition <= food.getTop()+30){
                            if((leftPosition+30 >= food.getLeft() && leftPosition+30 <= food.getLeft()+30) || (leftPosition >= food.getLeft() && leftPosition <= food.getLeft()+30)){
                                    foodsound.play();
                                    SnakeBody[SnakeBody.length]=new SnakePart();
                                    SnakeBody[SnakeBody.length-1].createPart(topPosition,leftPosition);
                                    SnakeBody[SnakeBody.length]=new SnakePart();
                                    SnakeBody[SnakeBody.length-1].createPart(topPosition,leftPosition);
                                    SnakeBody[SnakeBody.length]=new SnakePart();
                                    SnakeBody[SnakeBody.length-1].createPart(topPosition,leftPosition);
                            food.die();
                            }
                        }
                    
                    if(topPosition+30 >= food.getTop() && topPosition+30 <= food.getTop()+30){
                        if((leftPosition+30 >= food.getLeft() && leftPosition+40 <= food.getLeft()+30) || (leftPosition >= food.getLeft() && leftPosition <= food.getLeft()+30)){
                            foodsound.play();
                            SnakeBody[SnakeBody.length]=new SnakePart();
                            SnakeBody[SnakeBody.length-1].createPart(topPosition,leftPosition);
                            SnakeBody[SnakeBody.length]=new SnakePart();
                            SnakeBody[SnakeBody.length-1].createPart(topPosition,leftPosition);
                            SnakeBody[SnakeBody.length]=new SnakePart();
                            SnakeBody[SnakeBody.length-1].createPart(topPosition,leftPosition);
                            food.die();
                            }
                    }
                    SnakeBody[gps].setLocation(leftPosition,topPosition);
                }
            }
            gps++;
                if(gps == SnakeBody.length){
                    gps=0;

                }
    }
    var timer= setInterval(Game,100);
}
var stop=false;
document.getElementById("start").onmousedown=GameStart;

